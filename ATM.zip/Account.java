package ATM;
import java.text.DecimalFormat;
import java.util.Scanner;
import java.util.Date;



public class Account {
    private int customerID;
    private int pinNumber;

    Scanner i = new Scanner(System.in);

    DecimalFormat moneyFormat = new DecimalFormat("'$'###,##0.00");

    public int setCId(int customerID) {
        this.customerID = customerID;
        return customerID;
    }

    public int getCId() {
        return customerID;
    }

    public int setPNumber(int pinNumber) {
        this.pinNumber = pinNumber;
        return pinNumber;
    }

    public int getPNumber() {
        return pinNumber;
    }

    Date date = new Date();

    public void getTime() {
        System.out.println("Transition time:" + date);

    }


    // my part
    private double cBalance = 0;
    private double sBalance = 0;

    public double getcBalance() {
        return cBalance;
    }

    public double getsBalance() {
        return sBalance;
    }

    public double calcCW(double amount) {
        cBalance = (cBalance - amount);
        return cBalance;
    }

    public double calcSW(double amount) {
        sBalance = (sBalance - amount);
        return sBalance;
    }

    public double calcCD(double amount) {
        cBalance = (cBalance + amount);
        return cBalance;
    }

    public double calcSD(double amount) {
        sBalance = (sBalance + amount);
        return sBalance;
    }

    //withdraw method checking account
    public void getCWithdraw() {
        System.out.println("Balance of Checking Account  : " + moneyFormat.format(cBalance));
        System.out.println("Please enter amount you want to withdraw from Checking Account: ");
        double amount = i.nextDouble();
        if ((cBalance - amount) > 0) {
            calcCW(amount);

            System.out.println("New  balance in Checking Account: " + moneyFormat.format(cBalance));
            System.out.println("if you have finished your curriculum  don't Forget to logout. ");
        } else {
            System.out.println("Insufficient Balance");
        }
    }

    // deposit method  of checking account
    public void getCDeposit() {
        System.out.println("Balance of Checking Account : " + moneyFormat.format(cBalance));
        System.out.println("Please enter amount you want to deposit into Checking Account: ");
        double amount = i.nextDouble();
        if ((cBalance + amount) > 0) {
            calcCD(amount);

            System.out.println("New balance in Checking Account: " + moneyFormat.format(cBalance));
            System.out.println("if you have finished your curriculum  don't Forget to logout. ");
        } else {
            System.out.println("Insufficient Balance");
        }
    }

    //withdraw method of saving account
    public void getSWithdraw() {
        System.out.println("Balance of Saving Account: " + moneyFormat.format(sBalance));
        System.out.println("Please enter  amount you want to withdraw from saving Account: ");
        double amount = i.nextDouble();
        if ((sBalance - amount) > 0) {
            calcSW(amount);
            System.out.println("New  balance in Saving Account: " + moneyFormat.format(sBalance));
            System.out.println("if you have finished your curriculum  don't Forget to logout. ");
        } else {
            System.out.println("Insufficient Balance");
        }
    }

    //deposit method of saving account
    public void getSDeposit() {
        System.out.println("Balance of Saving Account : " + moneyFormat.format(sBalance));
        System.out.println("Please enter amount you want to deposit into saving Account: ");
        double amount = i.nextDouble();
        if ((sBalance + amount) > 0) {
            calcSD(amount);
            System.out.println("New  balance in Saving Account: " + moneyFormat.format(sBalance));
            System.out.println("if you have finished your curriculum  don't Forget to logout. ");
        } else {
            System.out.println("Insufficient Balance");
        }
    }
// loan methods

    double principal, emi;

    public double calctotal() {

        cBalance = (cBalance + principal);
        return cBalance;

    }

    public void getloan() {

        System.out.println("What kind of loan you want to take?");
        System.out.println("Type 1 for House loan for 4 years(48 months)");
        System.out.println("Type 2 for Car loan for 3 years (36 months)");
        System.out.println("Type 3 for Education for 2 years (24 months)");
        System.out.println("Type 4 for Emergency for 1 year (12 months) ");
        System.out.println(" Type 5 for TO get back to main menu");
        int selection = i.nextInt();
        switch (selection) {
            case 1:
                gethouseloan();
                break;
            case 2:
                getcarloan();
                break;
            case 3:
                geteduloan();
                break;
            case 4:
                getemloan();
                break;
            case 5:
                displaymenu account = new displaymenu();
                account.getAccountType();
                break;
            default:
                System.out.println("\n" + "Sorry.Invalid Choice" + "\n");
                displaymenu account1 = new displaymenu();
                account1.getAccountType();

        }
    }

    // house loan method
    public void gethouseloan() {

        double r = 10;
        double time = 4;
        System.out.print("Interest rate for house loan will be 10%");
        System.out.print("\nEnter your Principal amount : ");
        principal = i.nextFloat();

        r = r / (12 * 100);
        time = time * 12;


        emi = (principal * r * Math.pow(1 + r, time)) / (Math.pow(1 + r, time) - 1);

        System.out.print("Your EMI for house loan will be= " + emi + "\n");
        System.out.println("\n Type 1  For conformation taking loan");
        System.out.println("\n Type 2 for Previous menu");
        int selection = i.nextInt();
        switch (selection) {
            case 1:
                calctotal();
                System.out.println(" New balance of Checking Account" + cBalance);
                break;
            case 2:
                System.out.println("\n" + "Sorry.Invalid Choice" + "\n");
                getloan();
                break;
        }

    }

    // car loan method
    public void getcarloan() {
        double r = 8;
        double time = 3;
        System.out.print("Interest r for car loan will be 8%");
        System.out.print("\nEnter your Principal amount : ");
        principal = i.nextFloat();

        r = r / (12 * 100);
        time = time * 12;


        emi = (principal * r * Math.pow(1 + r, time)) / (Math.pow(1 + r, time) - 1);

        System.out.print("Your EMI for house loan will be= " + emi + "\n");
        System.out.println("\n Type 1  For conformation taking loan");
        System.out.println("\n Type 2 for Previous menu");
        int selection = i.nextInt();
        switch (selection) {
            case 1:
                calctotal();
                System.out.println(" New balance of Checking Account" + cBalance);
                break;
            case 2:
                System.out.println("\n" + "Sorry.Invalid Choice" + "\n");
                getloan();
                break;
        }

    }

    //Education loan method
    public void geteduloan() {
        double r = 7.5;
        double time = 2;
        System.out.print("Interest rate for house loan will be 7.5%");
        System.out.print("\nEnter your Principal amount : ");
        principal = i.nextFloat();

        r = r / (12 * 100);
        time = time * 12;


        emi = (principal * r * Math.pow(1 + r, time)) / (Math.pow(1 + r, time) - 1);

        System.out.print("Your EMI for house loan will be= " + emi + "\n");
        System.out.println("\n Type 1  For conformation taking loan");
        System.out.println("\n Type 2 for Previous menu");
        int selection = i.nextInt();
        switch (selection) {
            case 1:
                calctotal();
                System.out.println(" New balance of Checking Account" + cBalance);
                break;
            case 2:
                System.out.println("\n" + "Sorry.Invalid Choice" + "\n");
                getloan();
                break;
        }
    }

    //Emergency loan method
    public void getemloan() {
        double r = 5;
        double time = 1;
        System.out.print("Interest rate for house loan will be 10%");
        System.out.print("\nEnter your Principal amount : ");
        principal = i.nextFloat();

        r = r / (12 * 100);
        time = time * 12;


        emi = (principal * r * Math.pow(1 + r, time)) / (Math.pow(1 + r, time) - 1);

        System.out.print("Your EMI for house loan will be= " + emi + "\n");
        System.out.println("\n Type 1  For conformation taking loan");
        System.out.println("\n Type 2 for Previous menu");
        int selection = i.nextInt();
        switch (selection) {
            case 1:
                calctotal();
                System.out.println(" New balance of Checking Account" + cBalance);
                break;
            case 2:
                System.out.println("\n" + "Sorry.Invalid Choice" + "\n");
                getloan();
                break;
        }
    }


    //fixed deposit and show the total with interest & show the monthly deposit for fixed deposit.
    public void getfixeddeposit() {
        System.out.println("What kind of loan you want to take?");
        System.out.println("Enter 1 for fixed deposit for 2 years");
        System.out.println("Enter 2 for fixed deposit for 3 years");
        System.out.println("Enter 3 for fixed deposit for 5 years");
        System.out.println("Enter 4 for fixed deposit for 9 years");
        System.out.println("Enter 5 for Saving account menu ");
        int selection = i.nextInt();
        switch (selection) {
            case 1:
                get2year();
            case 2:
                get3year();
            case 3:
                get5year();

            case 4:
                get9year();

            case 7:
                displaymenu account2 = new displaymenu();
                account2.getSaving();
        }
    }

    public void get2year() {
        double interest;//interest

        System.out.println("There are four different option for you");
        System.out.println("Enter 1 for $50,000 fixed deposit for 2 years");
        System.out.println("Enter 2 for $100,000 deposit for 2 years");
        System.out.println("Enter 3 for $500,000 deposit for 2 years ");
        System.out.println("Enter 4 for Saving account");

        int selection = i.nextInt();
        switch (selection) {
            case 1:
                System.out.println("Your interest will be 5%");
                double clctotal = (50000 + (.05 * 50000));
                System.out.println("Your total amount will be " + clctotal);
                double clcmonthly = (50000 / 24);
                System.out.println("Monthly deposit  will be " + clcmonthly);

            case 2:
                System.out.println("Your interest will be 7%");
                double clctotal1 = (100000 + (.07 * 100000));
                System.out.println("Your total amount will be " + clctotal1);
                double clcmonthly1 = (100000 / 24);
                System.out.println("Monthly deposit  will be " + clcmonthly1);

            case 3:
                System.out.println("Your interest will be 10%");
                double clctotal2 = (500000 + (.1 * 500000));
                System.out.println("Your total amount will be " + clctotal2);
                double clcmonthly2 = (500000 / 24);
                System.out.println("Monthly deposit  will be " + clcmonthly2);

                case 4:
                    displaymenu account2 = new displaymenu();
                    account2.getSaving();

            default:
                displaymenu account3 = new displaymenu();
                account3.getSaving();
        }
    }

    public void get3year() {


        System.out.println("There are four different option for you");
        System.out.println("Enter 1 for $300,000 fixed deposit for 3 years");
        System.out.println("Enter 2 for $500,000 deposit for 3 years");
        System.out.println("Enter 3 for $700,000 deposit for 3 years ");
        int selection = i.nextInt();
        switch (selection) {
            case 1:
                System.out.println("Your interest will be 5%");
                double clctotal = (300000 + (.05 * 300000));
                System.out.println("Your total amount will be " + clctotal);
                double clcmonthly = (300000 / 36);
                System.out.println("Monthly deposit  will be " + clcmonthly);
            break;
                case 2:
                System.out.println("Your interest will be 7%");
                double clctotal1 = (500000 + (.07 * 500000));
                System.out.println("Your total amount will be " + clctotal1);
                double clcmonthly1 = (500000 / 36);
                System.out.println("Monthly deposit  will be " + clcmonthly1);
                    break;
            case 3:
                System.out.println("Your interest will be 12%");
                double clctotal2 = (700000 + (.12 * 700000));
                System.out.println("Your total amount will be " + clctotal2);
                double clcmonthly2 = (700000 / 36);
                System.out.println("Monthly deposit  will be " + clcmonthly2);
                break;
            case 4:
                displaymenu account2 = new displaymenu();
                account2.getSaving();
                break;
            default:
                displaymenu account3 = new displaymenu();
                account3.getSaving();
        }
    }
     public void get5year(){


         System.out.println("There are four different option for you");
         System.out.println("Enter 1 for $500,000 fixed deposit for 5 years");
         System.out.println("Enter 2 for $1000,000 deposit for 5 years");
         System.out.println("Enter 3 for $1500,000 deposit for 5 years ");
         int selection = i.nextInt();
         switch (selection) {
             case 1:
                 System.out.println("Your interest will be 7%");
                 double clctotal = (500000 + (.07 * 500000));
                 System.out.println("Your total amount will be " + clctotal);
                 double clcmonthly = (500000 / 60);
                 System.out.println("Monthly deposit  will be " + clcmonthly);
                 break;
             case 2:
                 System.out.println("Your interest will be 10%");
                 double clctotal1 = (1000000 + (.1 * 500000));
                 System.out.println("Your total amount will be " + clctotal1);
                 double clcmonthly1 = (1000000 / 60);
                 System.out.println("Monthly deposit  will be " + clcmonthly1);
                 break;
             case 3:
                 System.out.println("Your interest will be 12%");
                 double clctotal2 = (1500000 + (.12 * 1500000));
                 System.out.println("Your total amount will be " + clctotal2);
                 double clcmonthly2 = (1500000 / 60);
                 System.out.println("Monthly deposit  will be " + clcmonthly2);
                 break;
             case 4:
                 displaymenu account2 = new displaymenu();
                 account2.getSaving();
                 break;
             default:
                 displaymenu account3 = new displaymenu();
                 account3.getSaving();
         }

     }

    public void get9year(){


        System.out.println("There are four different option for you");
        System.out.println("Enter 1 for $10,000,00 fixed deposit for 9 years");
        System.out.println("Enter 2 for $15,000,00 deposit for 9 years");
        System.out.println("Enter 3 for $200,000,0 deposit for 9 years ");
        int selection = i.nextInt();
        switch (selection) {
            case 1:
                System.out.println("Your interest will be 10%");
                double clctotal = (1000000 + (.1 * 1000000));
                System.out.println("Your total amount will be " + clctotal);
                double clcmonthly = (1000000 /108);
                System.out.println("Monthly deposit  will be " + clcmonthly);
                break;
            case 2:
                System.out.println("Your interest will be 12%");
                double clctotal1 = (1500000 + (.1 * 1500000));
                System.out.println("Your total amount will be " + clctotal1);
                double clcmonthly1 = (1500000 / 108);
                System.out.println("Monthly deposit  will be " + clcmonthly1);
                break;
            case 3:
                System.out.println("Your interest will be 12%");
                double clctotal2 = (2000000 + (.14 * 2000000));
                System.out.println("Your total amount will be " + clctotal2);
                double clcmonthly2 = (2000000 / 108);
                System.out.println("Monthly deposit  will be " + clcmonthly2);
                break;
            case 4:
                displaymenu account2 = new displaymenu();
                account2.getSaving();
                break;
            default:
                displaymenu account3 = new displaymenu();
                account3.getSaving();
        }

    }
}
