package ATM;
import java.util.Scanner;

public class displaymenu extends Account {
    Scanner menuIn = new Scanner(System.in);

    public void getbanktype() {
        System.out.println("Select your Bank");
        System.out.println("1.Dutch Bangla Bank Ltd.");
        System.out.println("2.Dhaka Bank Ltd");
        System.out.println("3.Sonali Bank Ltd");
        System.out.println("4.United Commercial Bank Ltd");
        System.out.println("5.AB Bank Ltd.");
        System.out.println("Choice: ");
        int selection = menuIn.nextInt();
        switch (selection) {
            case 1:
                getAccountType();

            case 2:
                getAccountType();

            case 3:
                getAccountType();
            case 4:
                getAccountType();
            case 5:
                getAccountType();

        }

    }

    public void getAccountType() {
        System.out.println("Welcome to your account");
        System.out.println("Select the account you want to access: ");
        System.out.println("Type 1 for Checking Account");
        System.out.println("Type 2 for Savings Account");
        System.out.println("Type 3 for Exit");
        System.out.println("Choice: ");
        int selection = menuIn.nextInt();
        switch (selection) {
            case 1:
                getChecking();
                break;

            case 2:
                getSaving();
                break;

            case 3:
                System.out.println("Thank you.bye.");
                break;

            default:
                System.out.println("\n" + "Sorry.Invalid Choice" + "\n");
                getAccountType();
        }
    }

    public double getChecking() {
        System.out.println("**Checking Account Menu**: ");
        System.out.println("Type 1 for View Balance");
        System.out.println("Type 2 for Withdraw funds");
        System.out.println("Type 3 for Deposit funds");
        System.out.println("Type 4 for Loan : ");
        System.out.println("Type 5 for Log out");
        System.out.println("Choice: ");

        int selection = menuIn.nextInt();
        switch (selection) {
            case 1:
                System.out.println(" Balance of Checking Account: " + moneyFormat.format(getcBalance()));
                getAccountType();
                break;
            case 2:
                getCWithdraw();
                getTime();
                getAccountType();
                break;
            case 3:
                getCDeposit();
                getTime();
                getAccountType();
                break;
            case 5:
                System.out.println("Thank you.bye");
                break;
            case 4:
                getloan();
                break;

            default:
                System.out.println("\n" + "Invalid Choice" + "\n");
                getChecking();
        }
        return selection;
    }

    public void getSaving() {
        System.out.println("**Saving Account Menu**: ");
        System.out.println("Type 1 for  View Balance");
        System.out.println("Type 2 for Withdraw funds");
        System.out.println("Type 3 for Deposit Funds");
        System.out.println("Type 4 for Fixed Deposit Funds");
        System.out.println("Type 5 for Log out");
        System.out.println("Choice: ");

        int selection = menuIn.nextInt();
        switch (selection) {
            case 1:
                System.out.println("Balance of Saving account: " + moneyFormat.format(getsBalance()));
                getAccountType();
                break;
            case 2:
                getSWithdraw();
                getTime();
                getAccountType();
                break;
            case 3:
                getSDeposit();
                getTime();
                getAccountType();
                break;
            case 4:
                getfixeddeposit();
                getAccountType();
            case 5: System.out.println("Thank you, bye");
                break;
            default:
                System.out.println("\n" + "Invalid Choice" + "\n");
                getChecking();
        }
    }

}


