package ATM;
import java.io.IOException;
import java.text.DecimalFormat;
import java.util.HashMap;
import java.util.Map.Entry;
import java.util.Scanner;

public class loginoption extends displaymenu {
    Scanner menuIn = new Scanner(System.in);
    DecimalFormat moneyFormat = new DecimalFormat("'$'###,##0.00");
    HashMap<Integer, Integer> idpass = new HashMap<Integer, Integer>();

    public void getLogin() throws IOException {
        int x = 1;
        do {
            try {
                idpass.put(20431431, 1234);
                idpass.put(20431441, 1890);
                idpass.put(20431361, 2890);
                System.out.println("Welcome to ATM.");

                System.out.println("Please  Enter your Customer ID: \n");
                setCId(menuIn.nextInt());

                System.out.println("Enter your pin number: \n");
                setPNumber(menuIn.nextInt());
            } catch (Exception e) {
                System.out.println("\n" + "Invalid character. Please enter Only numbers" + "\n");
                x = 2;
            }
            for (Entry<Integer, Integer> entry : idpass.entrySet()) {
                if (entry.getKey() == getCId() && entry.getValue() == getPNumber()) {
                    getbanktype();
                }
            }
            System.out.println("\n" + "Invalid Customer number or pin");
        } while (x == 1);
    }


}
