package ATM;

import java.io.IOException;

public class ATM extends loginoption {
    public static void main(String[] args) throws IOException {
        loginoption option = new loginoption();
        option.getLogin();
    }
}
